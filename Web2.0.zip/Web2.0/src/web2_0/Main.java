package web2_0;

public class Main {

	public static void main(String[] args) {
		AppZip zip =new AppZip("D:/Web2.0/bin/web2_0/evidencia/testW2E1_Caso013.zip", "D:/Web2.0/bin/web2_0/evidencia");
		zip.comprimir();
	}

}

#!/bin/bash
/Library/Internet\ Plug-Ins/JavaAppletPlugin.plugin/Contents/Home/bin/java -cp bin:lib/* org.testng.TestNG testng.xml